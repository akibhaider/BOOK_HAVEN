#include "bookcart.h"
#include "ui_bookcart.h"

#include <manageauthors.h>
#include "digitallibrary.h"
#include <QSqlQueryModel>
#include <QDebug>
#include "authorslist.h"

QString isb;

bookcart::bookcart(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::bookcart)
{
    ui->setupUi(this);
    this->setWindowTitle("Book Cart");

    digitalLibrary lib;
    auto db = lib.db;

    QSqlQueryModel *model = new QSqlQueryModel;

    auto select = QSqlQuery(db);

    QString selectAll = {"SELECT * FROM books"};
    if(!select.exec(selectAll))
        qDebug() << "Cannot select from books";

    model->setQuery(select);

    ui->book_cart_view->setModel(model);

    //make connection

 connect(ui->book_cart_view, &QTableView::doubleClicked, this, &bookcart::showInfo);


}

bookcart::~bookcart()
{
    delete ui;
}




void bookcart::on_book_cart_view_doubleClicked(const QModelIndex &index)
{

}


void bookcart::showInfo()
{
    //get the clicked item
    auto row = ui->book_cart_view->currentIndex().row();

    //show information in the left side
    QString ISBN = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row, 1)).toString();
    QString name = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,2)).toString();
    QString author = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,3)).toString();
    QString genre = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,4)).toString();
    QString quantity = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,5)).toString();
    QString publisher = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,6)).toString();
    QString price = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,7)).toString();
    QString date = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,8)).toString();
    QString desc = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,9)).toString();
    QString cover = ui->book_cart_view->model()->data(ui->book_cart_view->model()->index(row,10)).toString();
    isb=ISBN;
    ui->coverLabel->setPixmap(cover);
    ui->ISBN->setText(ISBN);
    ui->name->setText(name);
    ui->author->setText(author);
    ui->genre->setText(genre);
    ui->publisher->setText(publisher);
    ui->price->setText(price);
    ui->quantity->setText(quantity);
    ui->date->setText(date);
    ui->desc->setText(desc);


}


void bookcart::on_buy_button_clicked()
{
    QString searchISBN = {"SELECT * FROM books WHERE ISBN = '%1'"};
    digitalLibrary lib;
    auto db=lib.db;
    auto query= QSqlQuery(db);

    if(!query.exec(searchISBN.arg(isb)))
        qDebug() << "Cannot select from books";

}

