#include "customer_registration_panel.h"
#include "ui_customer_registration_panel.h"
#include "mainwindow.h"
customer_registration_panel::customer_registration_panel(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::customer_registration_panel)
{
    ui->setupUi(this);
}

customer_registration_panel::~customer_registration_panel()
{
    delete ui;
}

void customer_registration_panel::on_customer_reg_to_view_clicked()
{
    MainWindow *ptr_main_win= new MainWindow();
    ptr_main_win->go_to_view();
    this->close();
}

