/****************************************************************************
** Meta object code from reading C++ file 'digitallibrary.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Library/digitallibrary.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'digitallibrary.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSdigitalLibraryENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSdigitalLibraryENDCLASS = QtMocHelpers::stringData(
    "digitalLibrary",
    "on_manageGenre_clicked",
    "",
    "on_manageAuthorButton_clicked",
    "on_addMemberBtn_clicked",
    "on_editMemberBtn_clicked",
    "on_deleteMemberBtn_clicked",
    "on_membersListBtn_clicked",
    "on_addBookBtn_clicked",
    "on_editBookBtn_clicked",
    "on_deleteBookBtn_clicked",
    "on_booksListBtn_clicked",
    "on_issueBookBtn_clicked",
    "on_returnBookBtn_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSdigitalLibraryENDCLASS_t {
    uint offsetsAndSizes[28];
    char stringdata0[15];
    char stringdata1[23];
    char stringdata2[1];
    char stringdata3[30];
    char stringdata4[24];
    char stringdata5[25];
    char stringdata6[27];
    char stringdata7[26];
    char stringdata8[22];
    char stringdata9[23];
    char stringdata10[25];
    char stringdata11[24];
    char stringdata12[24];
    char stringdata13[25];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSdigitalLibraryENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSdigitalLibraryENDCLASS_t qt_meta_stringdata_CLASSdigitalLibraryENDCLASS = {
    {
        QT_MOC_LITERAL(0, 14),  // "digitalLibrary"
        QT_MOC_LITERAL(15, 22),  // "on_manageGenre_clicked"
        QT_MOC_LITERAL(38, 0),  // ""
        QT_MOC_LITERAL(39, 29),  // "on_manageAuthorButton_clicked"
        QT_MOC_LITERAL(69, 23),  // "on_addMemberBtn_clicked"
        QT_MOC_LITERAL(93, 24),  // "on_editMemberBtn_clicked"
        QT_MOC_LITERAL(118, 26),  // "on_deleteMemberBtn_clicked"
        QT_MOC_LITERAL(145, 25),  // "on_membersListBtn_clicked"
        QT_MOC_LITERAL(171, 21),  // "on_addBookBtn_clicked"
        QT_MOC_LITERAL(193, 22),  // "on_editBookBtn_clicked"
        QT_MOC_LITERAL(216, 24),  // "on_deleteBookBtn_clicked"
        QT_MOC_LITERAL(241, 23),  // "on_booksListBtn_clicked"
        QT_MOC_LITERAL(265, 23),  // "on_issueBookBtn_clicked"
        QT_MOC_LITERAL(289, 24)   // "on_returnBookBtn_clicked"
    },
    "digitalLibrary",
    "on_manageGenre_clicked",
    "",
    "on_manageAuthorButton_clicked",
    "on_addMemberBtn_clicked",
    "on_editMemberBtn_clicked",
    "on_deleteMemberBtn_clicked",
    "on_membersListBtn_clicked",
    "on_addBookBtn_clicked",
    "on_editBookBtn_clicked",
    "on_deleteBookBtn_clicked",
    "on_booksListBtn_clicked",
    "on_issueBookBtn_clicked",
    "on_returnBookBtn_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSdigitalLibraryENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   86,    2, 0x08,    1 /* Private */,
       3,    0,   87,    2, 0x08,    2 /* Private */,
       4,    0,   88,    2, 0x08,    3 /* Private */,
       5,    0,   89,    2, 0x08,    4 /* Private */,
       6,    0,   90,    2, 0x08,    5 /* Private */,
       7,    0,   91,    2, 0x08,    6 /* Private */,
       8,    0,   92,    2, 0x08,    7 /* Private */,
       9,    0,   93,    2, 0x08,    8 /* Private */,
      10,    0,   94,    2, 0x08,    9 /* Private */,
      11,    0,   95,    2, 0x08,   10 /* Private */,
      12,    0,   96,    2, 0x08,   11 /* Private */,
      13,    0,   97,    2, 0x08,   12 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject digitalLibrary::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSdigitalLibraryENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSdigitalLibraryENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSdigitalLibraryENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<digitalLibrary, std::true_type>,
        // method 'on_manageGenre_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_manageAuthorButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addMemberBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_editMemberBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteMemberBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_membersListBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addBookBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_editBookBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteBookBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_booksListBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_issueBookBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_returnBookBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void digitalLibrary::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<digitalLibrary *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_manageGenre_clicked(); break;
        case 1: _t->on_manageAuthorButton_clicked(); break;
        case 2: _t->on_addMemberBtn_clicked(); break;
        case 3: _t->on_editMemberBtn_clicked(); break;
        case 4: _t->on_deleteMemberBtn_clicked(); break;
        case 5: _t->on_membersListBtn_clicked(); break;
        case 6: _t->on_addBookBtn_clicked(); break;
        case 7: _t->on_editBookBtn_clicked(); break;
        case 8: _t->on_deleteBookBtn_clicked(); break;
        case 9: _t->on_booksListBtn_clicked(); break;
        case 10: _t->on_issueBookBtn_clicked(); break;
        case 11: _t->on_returnBookBtn_clicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *digitalLibrary::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *digitalLibrary::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSdigitalLibraryENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int digitalLibrary::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
